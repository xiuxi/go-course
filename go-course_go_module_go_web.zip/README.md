go mod init github.com/xiuxi/go-course
go mod tidy

go run cmd/web/main.go
go build cmd/web/main.go



